<?php
if (!defined('TEMPLATES_VIEWS_PATH')) {
    define('TEMPLATES_VIEWS_PATH', $_SERVER['DOCUMENT_ROOT'] . '/ProyectoDaw/app/Views/partials/');
}
if (!defined('LOGO_TOURNAMENTS_PATH')) {
    define('LOGO_TOURNAMENTS_PATH', $_SERVER['DOCUMENT_ROOT'] . '/ProyectoDaw/public/img/logos_torneos/');
}
if (!defined('LOGO_EVENTS_PATH')) {
    define('LOGO_EVENTS_PATH', $_SERVER['DOCUMENT_ROOT'] . '/ProyectoDaw/public/img/logos_eventos/');
}
